# print the quotient of 15 and 13
print(15 / 13)