# print the product of 24 and 14
print(24 * 14)