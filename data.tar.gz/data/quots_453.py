# print the quotient of 16 and 4
print(16 / 4)