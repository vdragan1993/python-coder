# print the quotient of 5 and 17
print(5 / 17)