# print the quotient of 29 and 13
print(29 / 13)