# print the quotient of 2 and 9
print(2 / 9)