# print the difference of 24 and 24
print(24 - 24)