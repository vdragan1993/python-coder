# print the product of 13 and 27
print(13 * 27)