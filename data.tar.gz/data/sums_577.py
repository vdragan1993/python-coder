# print sum of 19 and 7
print(19 + 7)