# print sum of 4 and 21
print(4 + 21)