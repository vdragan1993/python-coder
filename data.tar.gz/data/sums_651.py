# print sum of 21 and 21
print(21 + 21)