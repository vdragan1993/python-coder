# print the difference of 23 and 9
print(23 - 9)