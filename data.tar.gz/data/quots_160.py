# print the quotient of 6 and 11
print(6 / 11)