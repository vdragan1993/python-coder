# print sum of 25 and 17
print(25 + 17)