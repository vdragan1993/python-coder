# print the quotient of 6 and 24
print(6 / 24)