# print sum of 20 and 22
print(20 + 22)