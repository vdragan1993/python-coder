# print sum of 12 and 24
print(12 + 24)