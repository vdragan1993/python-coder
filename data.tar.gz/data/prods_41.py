# print the product of 2 and 12
print(2 * 12)