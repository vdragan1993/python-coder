# print the product of 18 and 17
print(18 * 17)