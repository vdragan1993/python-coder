# print the product of 14 and 21
print(14 * 21)