# print True if the string 'cat' and 'dog' appear the same number of times in the catxdogxdogxcat
s = 'catxdogxdogxcat'
print(s.count('cat') == s.count('dog'))
