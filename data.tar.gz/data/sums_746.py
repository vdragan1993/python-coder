# print sum of 24 and 26
print(24 + 26)