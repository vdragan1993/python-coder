# print the quotient of 30 and 12
print(30 / 12)