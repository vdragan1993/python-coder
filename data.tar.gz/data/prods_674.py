# print the product of 23 and 15
print(23 * 15)