# print the product of 29 and 4
print(29 * 4)