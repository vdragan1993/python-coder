# print sum of 16 and 15
print(16 + 15)