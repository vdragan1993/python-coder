# print the quotient of 22 and 17
print(22 / 17)