# print the difference of 19 and 13
print(19 - 13)