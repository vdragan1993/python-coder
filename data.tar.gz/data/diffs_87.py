# print the difference of 2 and 27
print(2 - 27)