# print the quotient of 26 and 29
print(26 / 29)