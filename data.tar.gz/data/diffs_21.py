# print the difference of 0 and 21
print(0 - 21)