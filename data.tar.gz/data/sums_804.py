# print sum of 26 and 24
print(26 + 24)