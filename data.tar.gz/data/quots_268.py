# print the quotient of 9 and 29
print(9 / 29)