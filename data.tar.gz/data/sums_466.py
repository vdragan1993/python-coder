# print sum of 15 and 16
print(15 + 16)