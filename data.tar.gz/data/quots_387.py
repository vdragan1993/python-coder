# print the quotient of 13 and 28
print(13 / 28)