# print the product of 19 and 24
print(19 * 24)