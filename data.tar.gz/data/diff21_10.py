# print the absolute difference between -2 and 21, except return double the absolute difference if -2 is over 21
if -2 > 21:
    print(2 * abs(-2-21))
else:
    print(abs(-2 - 21))