# print the quotient of 3 and 3
print(3 / 3)