# print the product of 9 and 23
print(9 * 23)