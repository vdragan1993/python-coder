# print sum of 2 and 26
print(2 + 26)