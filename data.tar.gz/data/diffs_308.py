# print the difference of 10 and 8
print(10 - 8)