# print the product of 4 and 30
print(4 * 30)