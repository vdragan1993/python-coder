# print the difference of 25 and 2
print(25 - 2)