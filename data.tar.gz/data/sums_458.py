# print sum of 15 and 8
print(15 + 8)