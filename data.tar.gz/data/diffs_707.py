# print the difference of 23 and 17
print(23 - 17)