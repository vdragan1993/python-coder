# print the quotient of 19 and 9
print(19 / 9)