# print the sum of 3 and 1, if they are the same, then print double their sum
if 3 == 1:
    print(2 * (3 + 1))
else:
    print(3 + 1)