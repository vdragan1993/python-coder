# print the product of 15 and 4
print(15 * 4)