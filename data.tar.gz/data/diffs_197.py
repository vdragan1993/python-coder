# print the difference of 6 and 17
print(6 - 17)