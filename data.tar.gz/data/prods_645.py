# print the product of 22 and 16
print(22 * 16)