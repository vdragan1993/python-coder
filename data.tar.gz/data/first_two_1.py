# print a new string made of first two chars of abcdefg
s = 'abcdefg'
print(s[:2])
