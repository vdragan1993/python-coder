# print the difference of 20 and 25
print(20 - 25)