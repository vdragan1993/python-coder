# print sum of 19 and 15
print(19 + 15)