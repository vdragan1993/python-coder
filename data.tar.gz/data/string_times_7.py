# print 4 copies of 
print('' * 4)