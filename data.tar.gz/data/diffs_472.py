# print the difference of 15 and 22
print(15 - 22)