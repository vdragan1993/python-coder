# print the difference of 29 and 14
print(29 - 14)