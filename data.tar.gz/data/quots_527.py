# print the quotient of 18 and 18
print(18 / 18)