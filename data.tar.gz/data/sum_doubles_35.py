# print the sum of 3 and 0, if they are the same, then print double their sum
if 3 == 0:
    print(2 * (3 + 0))
else:
    print(3 + 0)