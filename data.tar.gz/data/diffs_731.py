# print the difference of 24 and 11
print(24 - 11)