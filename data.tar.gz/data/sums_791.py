# print sum of 26 and 11
print(26 + 11)