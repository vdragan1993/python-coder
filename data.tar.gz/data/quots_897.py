# print the quotient of 30 and 28
print(30 / 28)