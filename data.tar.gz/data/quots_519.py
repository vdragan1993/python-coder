# print the quotient of 18 and 10
print(18 / 10)