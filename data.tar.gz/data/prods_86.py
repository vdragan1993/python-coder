# print the product of 3 and 27
print(3 * 27)