# print the product of 21 and 1
print(21 * 1)