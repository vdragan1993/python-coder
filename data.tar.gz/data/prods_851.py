# print the product of 29 and 12
print(29 * 12)