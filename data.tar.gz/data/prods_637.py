# print the product of 22 and 8
print(22 * 8)