# print the difference of 20 and 4
print(20 - 4)