# print the product of 19 and 3
print(19 * 3)