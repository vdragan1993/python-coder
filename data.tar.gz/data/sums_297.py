# print sum of 9 and 27
print(9 + 27)