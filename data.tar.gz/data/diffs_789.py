# print the difference of 26 and 9
print(26 - 9)