# print the difference of 4 and 19
print(4 - 19)