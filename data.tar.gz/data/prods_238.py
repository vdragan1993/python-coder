# print the product of 8 and 29
print(8 * 29)