# print the product of 9 and 20
print(9 * 20)