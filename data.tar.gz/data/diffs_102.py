# print the difference of 3 and 12
print(3 - 12)