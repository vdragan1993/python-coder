# print sum of 14 and 9
print(14 + 9)