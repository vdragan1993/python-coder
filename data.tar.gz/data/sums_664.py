# print sum of 22 and 4
print(22 + 4)