# print sum of 12 and 11
print(12 + 11)