# print sum of 14 and 1
print(14 + 1)