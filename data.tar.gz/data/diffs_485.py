# print the difference of 16 and 5
print(16 - 5)