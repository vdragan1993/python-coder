# print a greeting of the form 'Hello Omega'
a = 'Omega'
print('Hello ' + a)
