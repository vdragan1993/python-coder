# print the product of 21 and 30
print(21 * 30)