# print the product of 18 and 30
print(18 * 30)