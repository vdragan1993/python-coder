# print the quotient of 19 and 4
print(19 / 4)