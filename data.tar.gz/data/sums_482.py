# print sum of 16 and 2
print(16 + 2)