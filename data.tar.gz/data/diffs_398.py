# print the difference of 13 and 8
print(13 - 8)