# print the product of 14 and 18
print(14 * 18)