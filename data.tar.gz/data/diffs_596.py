# print the difference of 19 and 26
print(19 - 26)