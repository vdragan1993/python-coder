# print the difference of 29 and 1
print(29 - 1)