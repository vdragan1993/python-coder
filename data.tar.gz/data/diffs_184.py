# print the difference of 6 and 4
print(6 - 4)