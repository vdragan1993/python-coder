# print sum of 13 and 10
print(13 + 10)