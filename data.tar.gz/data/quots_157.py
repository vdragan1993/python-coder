# print the quotient of 6 and 8
print(6 / 8)