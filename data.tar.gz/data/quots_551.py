# print the quotient of 19 and 12
print(19 / 12)