# print the quotient of 13 and 7
print(13 / 7)