# print the product of 6 and 7
print(6 * 7)