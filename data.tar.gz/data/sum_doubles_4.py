# print the sum of 1 and 3, if they are the same, then print double their sum
if 1 == 3:
    print(2 * (1 + 3))
else:
    print(1 + 3)