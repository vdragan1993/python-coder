# print sum of 10 and 26
print(10 + 26)