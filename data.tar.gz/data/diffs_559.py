# print the difference of 18 and 19
print(18 - 19)