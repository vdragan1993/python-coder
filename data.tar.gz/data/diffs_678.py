# print the difference of 22 and 18
print(22 - 18)