# print the product of 1 and 13
print(1 * 13)