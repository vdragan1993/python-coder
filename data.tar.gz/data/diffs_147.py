# print the difference of 4 and 27
print(4 - 27)