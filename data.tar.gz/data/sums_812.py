# print sum of 27 and 2
print(27 + 2)