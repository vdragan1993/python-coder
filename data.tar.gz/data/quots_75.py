# print the quotient of 3 and 16
print(3 / 16)