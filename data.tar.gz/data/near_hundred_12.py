# print True if -50 is within 10 of 100 or 200
print(abs(100--50) <= 10 or abs(200--50) <= 10)