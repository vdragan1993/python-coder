# print the product of 25 and 29
print(25 * 29)