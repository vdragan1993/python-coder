# print the product of 1 and 6
print(1 * 6)