# print the difference of 5 and 21
print(5 - 21)