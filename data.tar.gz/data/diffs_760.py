# print the difference of 25 and 10
print(25 - 10)