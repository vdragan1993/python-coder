# print sum of 2 and 18
print(2 + 18)