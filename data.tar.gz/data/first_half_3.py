# print a first half of ab
s = 'ab'
print(s[:len(s)/2])
