# print the quotient of 23 and 24
print(23 / 24)