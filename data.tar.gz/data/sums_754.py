# print sum of 25 and 4
print(25 + 4)