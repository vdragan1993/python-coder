# print the quotient of 7 and 2
print(7 / 2)