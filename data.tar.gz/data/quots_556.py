# print the quotient of 19 and 17
print(19 / 17)