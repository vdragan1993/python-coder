# print the difference of 10 and 3
print(10 - 3)