# print the quotient of 12 and 21
print(12 / 21)