# print the product of 20 and 2
print(20 * 2)