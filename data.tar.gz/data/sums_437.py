# print sum of 14 and 17
print(14 + 17)