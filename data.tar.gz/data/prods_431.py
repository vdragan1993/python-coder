# print the product of 15 and 12
print(15 * 12)