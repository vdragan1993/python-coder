# print sum of 7 and 21
print(7 + 21)