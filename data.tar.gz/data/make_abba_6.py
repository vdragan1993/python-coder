# print two strings, a= and b=y, in the order abba
a = ''
b = 'y'
print(a + b + b + a)
