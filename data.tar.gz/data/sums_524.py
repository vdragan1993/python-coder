# print sum of 17 and 14
print(17 + 14)