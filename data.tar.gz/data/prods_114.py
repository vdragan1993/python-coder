# print the product of 4 and 25
print(4 * 25)