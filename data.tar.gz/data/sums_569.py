# print sum of 18 and 29
print(18 + 29)