# print the difference of 8 and 10
print(8 - 10)