# print the quotient of 29 and 21
print(29 / 21)