# print sum of 29 and 8
print(29 + 8)