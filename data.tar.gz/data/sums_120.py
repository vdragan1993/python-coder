# print sum of 4 and 0
print(4 + 0)