# print sum of 12 and 16
print(12 + 16)