# print the quotient of 22 and 25
print(22 / 25)