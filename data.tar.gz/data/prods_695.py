# print the product of 24 and 6
print(24 * 6)