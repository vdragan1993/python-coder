# print the difference of 11 and 7
print(11 - 7)