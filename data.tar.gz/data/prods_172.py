# print the product of 6 and 23
print(6 * 23)