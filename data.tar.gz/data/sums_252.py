# print sum of 8 and 12
print(8 + 12)