# print the difference of 28 and 7
print(28 - 7)