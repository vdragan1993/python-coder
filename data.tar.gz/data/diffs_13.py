# print the difference of 0 and 13
print(0 - 13)