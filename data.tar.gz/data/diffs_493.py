# print the difference of 16 and 13
print(16 - 13)