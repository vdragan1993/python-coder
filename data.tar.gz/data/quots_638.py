# print the quotient of 22 and 9
print(22 / 9)