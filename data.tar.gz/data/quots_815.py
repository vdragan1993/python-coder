# print the quotient of 28 and 6
print(28 / 6)