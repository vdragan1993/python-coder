# print the difference of 21 and 11
print(21 - 11)