# print the quotient of 11 and 22
print(11 / 22)