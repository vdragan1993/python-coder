# print the product of 5 and 24
print(5 * 24)