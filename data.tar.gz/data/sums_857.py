# print sum of 28 and 17
print(28 + 17)