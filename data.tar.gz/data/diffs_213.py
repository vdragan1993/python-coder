# print the difference of 7 and 3
print(7 - 3)