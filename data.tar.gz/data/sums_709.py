# print sum of 23 and 19
print(23 + 19)