# print the difference of 10 and 29
print(10 - 29)