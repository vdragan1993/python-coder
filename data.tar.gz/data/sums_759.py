# print sum of 25 and 9
print(25 + 9)