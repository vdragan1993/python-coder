# print the product of 11 and 21
print(11 * 21)