# print the quotient of 6 and 16
print(6 / 16)