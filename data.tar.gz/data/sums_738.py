# print sum of 24 and 18
print(24 + 18)