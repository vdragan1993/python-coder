# print the product of 2 and 20
print(2 * 20)