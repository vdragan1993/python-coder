# print the product of 13 and 6
print(13 * 6)