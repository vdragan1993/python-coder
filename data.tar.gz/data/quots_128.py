# print the quotient of 5 and 9
print(5 / 9)