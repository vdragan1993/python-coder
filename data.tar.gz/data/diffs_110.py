# print the difference of 3 and 20
print(3 - 20)