# print sum of 8 and 20
print(8 + 20)