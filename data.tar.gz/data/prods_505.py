# print the product of 17 and 26
print(17 * 26)