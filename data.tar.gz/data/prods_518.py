# print the product of 18 and 9
print(18 * 9)