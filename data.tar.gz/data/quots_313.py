# print the quotient of 11 and 14
print(11 / 14)