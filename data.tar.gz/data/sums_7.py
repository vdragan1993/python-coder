# print sum of 0 and 7
print(0 + 7)