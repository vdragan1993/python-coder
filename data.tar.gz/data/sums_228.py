# print sum of 7 and 18
print(7 + 18)