# print the quotient of 5 and 4
print(5 / 4)