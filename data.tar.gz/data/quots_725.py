# print the quotient of 25 and 6
print(25 / 6)