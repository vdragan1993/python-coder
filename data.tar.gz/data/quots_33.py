# print the quotient of 2 and 4
print(2 / 4)