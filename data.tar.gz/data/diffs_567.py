# print the difference of 18 and 27
print(18 - 27)