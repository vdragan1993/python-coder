# print the difference of 23 and 25
print(23 - 25)