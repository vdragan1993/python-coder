# print the product of 30 and 19
print(30 * 19)