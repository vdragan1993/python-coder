# print sum of 29 and 3
print(29 + 3)