# print the difference of 3 and 5
print(3 - 5)