# print number of 9's in the given array []
print([].count(9))