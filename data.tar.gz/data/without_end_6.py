# print a version of kitten without the first and the last char
s = 'kitten'
if len(s) == 2:
    print('')
else:
    print(s[1:len(s)-1])
