# print the product of 11 and 5
print(11 * 5)