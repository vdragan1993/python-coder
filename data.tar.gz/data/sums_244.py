# print sum of 8 and 4
print(8 + 4)