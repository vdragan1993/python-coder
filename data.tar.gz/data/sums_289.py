# print sum of 9 and 19
print(9 + 19)