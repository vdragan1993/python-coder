# print the quotient of 18 and 26
print(18 / 26)