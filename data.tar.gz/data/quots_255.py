# print the quotient of 9 and 16
print(9 / 16)