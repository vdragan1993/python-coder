# print the product of 9 and 7
print(9 * 7)