# print sum of 1 and 11
print(1 + 11)