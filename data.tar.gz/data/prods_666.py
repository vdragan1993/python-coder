# print the product of 23 and 7
print(23 * 7)