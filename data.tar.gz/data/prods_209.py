# print the product of 7 and 30
print(7 * 30)