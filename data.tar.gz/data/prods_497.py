# print the product of 17 and 18
print(17 * 18)