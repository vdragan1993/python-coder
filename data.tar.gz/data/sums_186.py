# print sum of 6 and 6
print(6 + 6)