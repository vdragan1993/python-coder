# print sum of 16 and 7
print(16 + 7)