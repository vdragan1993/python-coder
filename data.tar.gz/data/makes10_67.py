# print True if 10 or 10 is 10 or if their sum is 10
print(10 == 10 or 10 == 10 or 10+10 == 10)