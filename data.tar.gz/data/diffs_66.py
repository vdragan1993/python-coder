# print the difference of 2 and 6
print(2 - 6)