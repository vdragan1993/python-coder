# print sum of 22 and 12
print(22 + 12)