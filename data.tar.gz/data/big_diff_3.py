# print the difference between the largest and smallest values in the array [2, 10]
nums = [2, 10]
print(max(nums) - min(nums))
