# print the product of 14 and 5
print(14 * 5)