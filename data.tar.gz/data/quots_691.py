# print the quotient of 24 and 2
print(24 / 2)