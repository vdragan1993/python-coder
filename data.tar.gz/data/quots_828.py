# print the quotient of 28 and 19
print(28 / 19)