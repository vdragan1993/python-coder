# print the product of 14 and 26
print(14 * 26)