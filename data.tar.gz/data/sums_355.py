# print sum of 11 and 25
print(11 + 25)