# print the difference of 28 and 15
print(28 - 15)