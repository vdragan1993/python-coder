# print sum of 16 and 23
print(16 + 23)