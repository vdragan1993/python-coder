# print the quotient of 27 and 20
print(27 / 20)