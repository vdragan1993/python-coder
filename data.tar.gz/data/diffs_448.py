# print the difference of 14 and 28
print(14 - 28)