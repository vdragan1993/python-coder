# print sum of 10 and 18
print(10 + 18)