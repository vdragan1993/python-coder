# print the difference of 18 and 6
print(18 - 6)