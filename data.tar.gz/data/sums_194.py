# print sum of 6 and 14
print(6 + 14)