# print sum of 7 and 5
print(7 + 5)