# print the product of 19 and 8
print(19 * 8)