# print the quotient of 20 and 24
print(20 / 24)