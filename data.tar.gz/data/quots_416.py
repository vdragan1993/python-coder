# print the quotient of 14 and 27
print(14 / 27)