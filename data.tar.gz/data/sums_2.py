# print sum of 0 and 2
print(0 + 2)