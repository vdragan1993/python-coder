# print the difference of 14 and 7
print(14 - 7)