# print sum of 1 and 3
print(1 + 3)