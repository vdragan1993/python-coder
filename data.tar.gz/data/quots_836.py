# print the quotient of 28 and 27
print(28 / 27)