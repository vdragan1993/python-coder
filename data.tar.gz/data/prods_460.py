# print the product of 16 and 11
print(16 * 11)