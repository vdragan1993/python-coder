# print array of second elements of arrays a=[1, 2, 3] and b=[4, 1, 1]
a = [1, 2, 3]
b = [4, 1, 1]
ret = []
ret.append(a[1])
ret.append(b[1])
print(ret)
