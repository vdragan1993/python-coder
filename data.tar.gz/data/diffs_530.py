# print the difference of 17 and 20
print(17 - 20)