# print the quotient of 13 and 20
print(13 / 20)