# print the number of times that the string 'hi' appears anywhere in the Hi is no HI and ahI
s = 'Hi is no HI and ahI'
print(s.count('hi'))
