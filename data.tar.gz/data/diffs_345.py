# print the difference of 11 and 15
print(11 - 15)