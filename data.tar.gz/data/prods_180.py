# print the product of 7 and 1
print(7 * 1)