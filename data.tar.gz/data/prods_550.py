# print the product of 19 and 11
print(19 * 11)