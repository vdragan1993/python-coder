# print the difference of 7 and 11
print(7 - 11)