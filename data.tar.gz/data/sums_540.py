# print sum of 18 and 0
print(18 + 0)