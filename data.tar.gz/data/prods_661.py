# print the product of 23 and 2
print(23 * 2)