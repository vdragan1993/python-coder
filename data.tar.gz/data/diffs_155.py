# print the difference of 5 and 5
print(5 - 5)