# print the quotient of 15 and 26
print(15 / 26)