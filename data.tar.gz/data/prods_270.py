# print the product of 10 and 1
print(10 * 1)