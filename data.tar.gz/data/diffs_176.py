# print the difference of 5 and 26
print(5 - 26)