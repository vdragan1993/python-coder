# print the product of 14 and 13
print(14 * 13)