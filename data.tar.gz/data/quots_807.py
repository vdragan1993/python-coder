# print the quotient of 27 and 28
print(27 / 28)