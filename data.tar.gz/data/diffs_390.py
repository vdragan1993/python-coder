# print the difference of 13 and 0
print(13 - 0)