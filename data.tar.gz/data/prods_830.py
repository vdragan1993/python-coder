# print the product of 28 and 21
print(28 * 21)