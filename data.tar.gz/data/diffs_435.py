# print the difference of 14 and 15
print(14 - 15)