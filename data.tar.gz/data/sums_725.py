# print sum of 24 and 5
print(24 + 5)