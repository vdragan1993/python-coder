# print the difference of 27 and 29
print(27 - 29)