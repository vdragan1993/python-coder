# print True if 10 or 9 is 10 or if their sum is 10
print(10 == 10 or 9 == 10 or 10+9 == 10)