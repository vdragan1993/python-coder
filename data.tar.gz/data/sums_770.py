# print sum of 25 and 20
print(25 + 20)