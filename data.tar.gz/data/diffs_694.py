# print the difference of 23 and 4
print(23 - 4)