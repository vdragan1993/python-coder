# print the difference of 28 and 28
print(28 - 28)