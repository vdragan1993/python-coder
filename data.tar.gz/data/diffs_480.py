# print the difference of 16 and 0
print(16 - 0)