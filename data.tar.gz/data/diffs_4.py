# print the difference of 0 and 4
print(0 - 4)