# print sum of 12 and 3
print(12 + 3)