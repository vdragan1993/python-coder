# print the difference of 17 and 28
print(17 - 28)