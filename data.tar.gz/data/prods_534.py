# print the product of 18 and 25
print(18 * 25)