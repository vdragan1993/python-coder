# print the difference between the largest and smallest values in the array [7, 6, 8, 5]
nums = [7, 6, 8, 5]
print(max(nums) - min(nums))
