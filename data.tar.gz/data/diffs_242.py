# print the difference of 8 and 2
print(8 - 2)