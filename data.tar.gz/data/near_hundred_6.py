# print True if -101 is within 10 of 100 or 200
print(abs(100--101) <= 10 or abs(200--101) <= 10)