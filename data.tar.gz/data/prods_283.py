# print the product of 10 and 14
print(10 * 14)