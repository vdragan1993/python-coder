# print the product of 15 and 25
print(15 * 25)