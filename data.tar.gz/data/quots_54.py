# print the quotient of 2 and 25
print(2 / 25)