# print sum of 26 and 3
print(26 + 3)