# print the quotient of 10 and 2
print(10 / 2)