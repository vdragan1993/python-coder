# print the quotient of 17 and 27
print(17 / 27)