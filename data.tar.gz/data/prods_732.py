# print the product of 25 and 13
print(25 * 13)