# print the product of 1 and 1
print(1 * 1)