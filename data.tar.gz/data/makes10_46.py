# print True if 8 or 9 is 10 or if their sum is 10
print(8 == 10 or 9 == 10 or 8+9 == 10)