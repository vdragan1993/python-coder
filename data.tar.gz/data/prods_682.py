# print the product of 23 and 23
print(23 * 23)