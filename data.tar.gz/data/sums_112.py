# print sum of 3 and 22
print(3 + 22)