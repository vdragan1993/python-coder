# print sum of 19 and 28
print(19 + 28)