# print the product of 14 and 10
print(14 * 10)