# print the sum of 0 and 0, if they are the same, then print double their sum
if 0 == 0:
    print(2 * (0 + 0))
else:
    print(0 + 0)