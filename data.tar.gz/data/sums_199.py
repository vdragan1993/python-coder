# print sum of 6 and 19
print(6 + 19)