# print sum of 7 and 13
print(7 + 13)