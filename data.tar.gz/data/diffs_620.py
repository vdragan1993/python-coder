# print the difference of 20 and 20
print(20 - 20)