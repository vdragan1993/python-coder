# print the difference of 2 and 22
print(2 - 22)