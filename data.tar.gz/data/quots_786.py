# print the quotient of 27 and 7
print(27 / 7)