# print the quotient of 14 and 22
print(14 / 22)