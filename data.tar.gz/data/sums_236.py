# print sum of 7 and 26
print(7 + 26)