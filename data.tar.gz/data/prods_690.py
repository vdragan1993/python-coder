# print the product of 24 and 1
print(24 * 1)