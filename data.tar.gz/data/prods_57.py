# print the product of 2 and 28
print(2 * 28)