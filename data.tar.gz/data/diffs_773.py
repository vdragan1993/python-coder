# print the difference of 25 and 23
print(25 - 23)