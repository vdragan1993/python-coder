# print the quotient of 17 and 19
print(17 / 19)