# print the difference of 21 and 3
print(21 - 3)