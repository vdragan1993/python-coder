# print the quotient of 14 and 14
print(14 / 14)