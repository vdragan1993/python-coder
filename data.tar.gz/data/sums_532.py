# print sum of 17 and 22
print(17 + 22)