# print the difference of 24 and 16
print(24 - 16)