# print the product of 28 and 13
print(28 * 13)