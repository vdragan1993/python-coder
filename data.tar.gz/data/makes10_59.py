# print True if 8 or 2 is 10 or if their sum is 10
print(8 == 10 or 2 == 10 or 8+2 == 10)