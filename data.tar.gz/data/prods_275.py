# print the product of 10 and 6
print(10 * 6)