# print the product of 27 and 19
print(27 * 19)