# print the product of 25 and 21
print(25 * 21)