# print the difference of 9 and 9
print(9 - 9)