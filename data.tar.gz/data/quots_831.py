# print the quotient of 28 and 22
print(28 / 22)