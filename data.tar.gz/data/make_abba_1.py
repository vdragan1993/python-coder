# print two strings, a=Yo and b=Alice, in the order abba
a = 'Yo'
b = 'Alice'
print(a + b + b + a)
