# print the quotient of 10 and 15
print(10 / 15)