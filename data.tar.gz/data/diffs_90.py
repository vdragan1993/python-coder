# print the difference of 3 and 0
print(3 - 0)