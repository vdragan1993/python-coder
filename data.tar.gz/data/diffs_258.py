# print the difference of 8 and 18
print(8 - 18)