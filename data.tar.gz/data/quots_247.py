# print the quotient of 9 and 8
print(9 / 8)