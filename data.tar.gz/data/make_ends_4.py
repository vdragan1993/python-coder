# print array containing the first and last elements from the [7, 4]
nums = [7, 4]
ret = []
ret.append(nums[0])
ret.append(nums[len(nums) - 1])
print(ret)
