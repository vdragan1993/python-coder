# print first three elements of [1, 2, 1] in reverse order
nums = [1, 2, 1]
ret = []
ret.append(nums[2])
ret.append(nums[1])
ret.append(nums[0])
print(ret)
