# print the difference of 1 and 28
print(1 - 28)