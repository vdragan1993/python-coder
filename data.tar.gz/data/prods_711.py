# print the product of 24 and 22
print(24 * 22)