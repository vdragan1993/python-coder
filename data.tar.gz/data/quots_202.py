# print the quotient of 7 and 23
print(7 / 23)