# print the product of 9 and 28
print(9 * 28)