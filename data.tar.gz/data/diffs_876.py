# print the difference of 29 and 6
print(29 - 6)