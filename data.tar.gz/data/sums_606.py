# print sum of 20 and 6
print(20 + 6)