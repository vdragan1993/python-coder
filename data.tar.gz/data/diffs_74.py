# print the difference of 2 and 14
print(2 - 14)