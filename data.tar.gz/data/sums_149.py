# print sum of 4 and 29
print(4 + 29)