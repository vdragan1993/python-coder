# print the quotient of 24 and 23
print(24 / 23)