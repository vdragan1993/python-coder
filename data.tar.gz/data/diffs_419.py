# print the difference of 13 and 29
print(13 - 29)