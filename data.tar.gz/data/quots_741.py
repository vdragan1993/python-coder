# print the quotient of 25 and 22
print(25 / 22)