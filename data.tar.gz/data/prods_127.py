# print the product of 5 and 8
print(5 * 8)