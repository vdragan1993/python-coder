# print the quotient of 11 and 1
print(11 / 1)