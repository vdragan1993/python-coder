# print True if 90 is within 10 of 100 or 200
print(abs(100-90) <= 10 or abs(200-90) <= 10)