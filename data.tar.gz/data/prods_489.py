# print the product of 17 and 10
print(17 * 10)