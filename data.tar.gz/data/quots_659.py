# print the quotient of 22 and 30
print(22 / 30)