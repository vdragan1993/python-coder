# print the product of 4 and 10
print(4 * 10)