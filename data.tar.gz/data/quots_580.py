# print the quotient of 20 and 11
print(20 / 11)