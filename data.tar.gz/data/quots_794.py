# print the quotient of 27 and 15
print(27 / 15)