# print the product of 4 and 5
print(4 * 5)