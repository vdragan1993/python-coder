# print the product of 7 and 22
print(7 * 22)