# print the quotient of 2 and 17
print(2 / 17)