# print the product of 10 and 22
print(10 * 22)