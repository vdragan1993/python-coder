# print the product of 12 and 20
print(12 * 20)