# print sum of 11 and 12
print(11 + 12)