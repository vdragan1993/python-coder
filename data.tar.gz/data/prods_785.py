# print the product of 27 and 6
print(27 * 6)