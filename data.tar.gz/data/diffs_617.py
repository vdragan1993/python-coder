# print the difference of 20 and 17
print(20 - 17)