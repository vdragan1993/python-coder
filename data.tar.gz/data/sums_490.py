# print sum of 16 and 10
print(16 + 10)