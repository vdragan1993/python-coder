# print sum of 11 and 17
print(11 + 17)