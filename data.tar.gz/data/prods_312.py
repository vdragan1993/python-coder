# print the product of 11 and 13
print(11 * 13)