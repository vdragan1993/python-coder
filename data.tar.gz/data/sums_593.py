# print sum of 19 and 23
print(19 + 23)