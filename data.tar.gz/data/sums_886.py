# print sum of 29 and 16
print(29 + 16)