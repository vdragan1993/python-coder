# print sum of 3 and 4
print(3 + 4)