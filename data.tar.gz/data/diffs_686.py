# print the difference of 22 and 26
print(22 - 26)