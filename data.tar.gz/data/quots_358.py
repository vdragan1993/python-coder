# print the quotient of 12 and 29
print(12 / 29)