# print sum of 21 and 13
print(21 + 13)