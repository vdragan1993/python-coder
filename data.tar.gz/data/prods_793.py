# print the product of 27 and 14
print(27 * 14)