# print sum of 0 and 25
print(0 + 25)