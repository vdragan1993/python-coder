# print True if the string 'cat' and 'dog' appear the same number of times in the cat
s = 'cat'
print(s.count('cat') == s.count('dog'))
