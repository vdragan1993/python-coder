# print the difference of 6 and 25
print(6 - 25)