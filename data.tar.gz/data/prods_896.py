# print the product of 30 and 27
print(30 * 27)