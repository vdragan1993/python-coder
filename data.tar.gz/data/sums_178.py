# print sum of 5 and 28
print(5 + 28)