# print the product of 6 and 2
print(6 * 2)