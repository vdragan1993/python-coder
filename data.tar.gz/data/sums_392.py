# print sum of 13 and 2
print(13 + 2)