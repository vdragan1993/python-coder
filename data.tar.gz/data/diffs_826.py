# print the difference of 27 and 16
print(27 - 16)