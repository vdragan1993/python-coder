# print the quotient of 8 and 30
print(8 / 30)