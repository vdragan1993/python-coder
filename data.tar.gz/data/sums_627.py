# print sum of 20 and 27
print(20 + 27)