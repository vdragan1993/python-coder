# print sum of 6 and 27
print(6 + 27)