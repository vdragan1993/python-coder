# print the quotient of 10 and 23
print(10 / 23)