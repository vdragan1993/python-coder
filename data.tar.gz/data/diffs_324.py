# print the difference of 10 and 24
print(10 - 24)