# print the quotient of 25 and 14
print(25 / 14)