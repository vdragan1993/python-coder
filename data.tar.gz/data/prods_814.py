# print the product of 28 and 5
print(28 * 5)