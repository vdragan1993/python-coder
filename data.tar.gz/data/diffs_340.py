# print the difference of 11 and 10
print(11 - 10)