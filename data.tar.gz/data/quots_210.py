# print the quotient of 8 and 1
print(8 / 1)