# print the product of 16 and 3
print(16 * 3)