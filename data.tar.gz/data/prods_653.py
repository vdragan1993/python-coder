# print the product of 22 and 24
print(22 * 24)