# print the difference of 11 and 23
print(11 - 23)