# print sum of 17 and 6
print(17 + 6)