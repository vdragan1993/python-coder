# print sum of 21 and 5
print(21 + 5)