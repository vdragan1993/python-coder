# print a version of java without the first and the last char
s = 'java'
if len(s) == 2:
    print('')
else:
    print(s[1:len(s)-1])
