# print a two chars for every char in a .
s = '.'
sol = ''
for char in s:
    sol += char * 2

print(sol)
