# print the quotient of 5 and 25
print(5 / 25)