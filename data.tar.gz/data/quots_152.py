# print the quotient of 6 and 3
print(6 / 3)