# print the product of 3 and 19
print(3 * 19)