# print the difference of 24 and 3
print(24 - 3)