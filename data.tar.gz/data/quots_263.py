# print the quotient of 9 and 24
print(9 / 24)