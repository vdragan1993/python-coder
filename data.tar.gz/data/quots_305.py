# print the quotient of 11 and 6
print(11 / 6)