# print the sum of 2 and 1, if they are the same, then print double their sum
if 2 == 1:
    print(2 * (2 + 1))
else:
    print(2 + 1)