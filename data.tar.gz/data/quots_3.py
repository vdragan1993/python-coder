# print the quotient of 1 and 4
print(1 / 4)