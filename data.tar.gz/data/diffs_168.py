# print the difference of 5 and 18
print(5 - 18)