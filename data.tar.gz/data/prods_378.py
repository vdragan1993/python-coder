# print the product of 13 and 19
print(13 * 19)