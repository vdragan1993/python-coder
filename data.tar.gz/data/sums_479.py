# print sum of 15 and 29
print(15 + 29)