# print the difference of 9 and 25
print(9 - 25)