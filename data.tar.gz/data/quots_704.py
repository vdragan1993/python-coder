# print the quotient of 24 and 15
print(24 / 15)