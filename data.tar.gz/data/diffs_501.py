# print the difference of 16 and 21
print(16 - 21)