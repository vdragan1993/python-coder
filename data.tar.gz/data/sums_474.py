# print sum of 15 and 24
print(15 + 24)