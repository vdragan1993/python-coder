# print True if 9 or 2 is 10 or if their sum is 10
print(9 == 10 or 2 == 10 or 9+2 == 10)