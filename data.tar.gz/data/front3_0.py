# print a new string which is 3 copies of the first 3 chars of Java
string = 'Java'
cpy = string[0] + string[1] + string[2]
print(cpy + cpy + cpy)