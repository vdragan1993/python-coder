# print sum of 11 and 9
print(11 + 9)