# print the quotient of 1 and 18
print(1 / 18)