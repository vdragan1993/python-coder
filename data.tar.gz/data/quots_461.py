# print the quotient of 16 and 12
print(16 / 12)