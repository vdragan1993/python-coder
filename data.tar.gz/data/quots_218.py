# print the quotient of 8 and 9
print(8 / 9)