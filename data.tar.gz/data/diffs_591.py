# print the difference of 19 and 21
print(19 - 21)