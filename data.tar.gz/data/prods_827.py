# print the product of 28 and 18
print(28 * 18)