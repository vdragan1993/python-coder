# print sum of 27 and 10
print(27 + 10)