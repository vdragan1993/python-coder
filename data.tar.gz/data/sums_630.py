# print sum of 21 and 0
print(21 + 0)