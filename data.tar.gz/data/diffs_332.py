# print the difference of 11 and 2
print(11 - 2)