# print the product of 13 and 14
print(13 * 14)