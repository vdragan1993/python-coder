# print the difference of 12 and 1
print(12 - 1)