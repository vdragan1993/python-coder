# print the quotient of 19 and 25
print(19 / 25)