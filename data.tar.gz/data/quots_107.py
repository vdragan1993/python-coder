# print the quotient of 4 and 18
print(4 / 18)