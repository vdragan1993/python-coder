# print the difference of 27 and 24
print(27 - 24)