# print the quotient of 10 and 7
print(10 / 7)