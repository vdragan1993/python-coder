# print the difference of 6 and 20
print(6 - 20)