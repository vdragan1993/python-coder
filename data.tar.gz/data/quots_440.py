# print the quotient of 15 and 21
print(15 / 21)