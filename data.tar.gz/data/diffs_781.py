# print the difference of 26 and 1
print(26 - 1)