# print the quotient of 25 and 30
print(25 / 30)