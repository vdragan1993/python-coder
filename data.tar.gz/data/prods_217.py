# print the product of 8 and 8
print(8 * 8)