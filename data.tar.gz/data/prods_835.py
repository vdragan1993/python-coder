# print the product of 28 and 26
print(28 * 26)