# print the difference of 14 and 23
print(14 - 23)