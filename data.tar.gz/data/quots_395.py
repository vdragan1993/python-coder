# print the quotient of 14 and 6
print(14 / 6)