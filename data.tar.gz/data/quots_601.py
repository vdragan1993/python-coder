# print the quotient of 21 and 2
print(21 / 2)