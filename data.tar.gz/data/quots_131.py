# print the quotient of 5 and 12
print(5 / 12)