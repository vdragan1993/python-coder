# print the difference of 15 and 1
print(15 - 1)