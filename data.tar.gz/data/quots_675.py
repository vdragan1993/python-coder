# print the quotient of 23 and 16
print(23 / 16)