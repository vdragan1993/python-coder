# print the quotient of 4 and 2
print(4 / 2)