# print the product of 22 and 29
print(22 * 29)