# print the product of 5 and 3
print(5 * 3)