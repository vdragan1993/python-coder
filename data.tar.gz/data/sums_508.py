# print sum of 16 and 28
print(16 + 28)