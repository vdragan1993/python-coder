# print True if array [7, 7] contains a 2 or a 3
nums = [7, 7]
if 2 in nums or 3 in nums:
    print('True')
else:
    print('False')
