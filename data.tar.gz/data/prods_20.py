# print the product of 1 and 21
print(1 * 21)