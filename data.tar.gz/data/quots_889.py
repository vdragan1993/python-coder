# print the quotient of 30 and 20
print(30 / 20)