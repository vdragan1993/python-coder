# print the difference of 19 and 18
print(19 - 18)