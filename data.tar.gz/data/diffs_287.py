# print the difference of 9 and 17
print(9 - 17)