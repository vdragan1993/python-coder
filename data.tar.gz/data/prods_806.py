# print the product of 27 and 27
print(27 * 27)