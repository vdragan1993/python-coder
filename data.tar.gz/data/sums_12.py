# print sum of 0 and 12
print(0 + 12)