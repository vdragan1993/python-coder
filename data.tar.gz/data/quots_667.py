# print the quotient of 23 and 8
print(23 / 8)