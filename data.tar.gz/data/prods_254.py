# print the product of 9 and 15
print(9 * 15)