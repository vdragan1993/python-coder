# print the quotient of 29 and 5
print(29 / 5)