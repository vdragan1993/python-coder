# print the quotient of 3 and 11
print(3 / 11)