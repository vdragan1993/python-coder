# print the product of 26 and 20
print(26 * 20)