# print the quotient of 3 and 24
print(3 / 24)