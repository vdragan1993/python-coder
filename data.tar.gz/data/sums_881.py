# print sum of 29 and 11
print(29 + 11)