# print sum of 3 and 9
print(3 + 9)