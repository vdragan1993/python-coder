# print sum of 22 and 20
print(22 + 20)