# print the difference between the largest and smallest values in the array [2]
nums = [2]
print(max(nums) - min(nums))
