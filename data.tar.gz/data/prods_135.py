# print the product of 5 and 16
print(5 * 16)