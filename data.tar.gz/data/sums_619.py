# print sum of 20 and 19
print(20 + 19)