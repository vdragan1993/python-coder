# print the product of 4 and 17
print(4 * 17)