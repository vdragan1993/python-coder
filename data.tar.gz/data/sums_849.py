# print sum of 28 and 9
print(28 + 9)