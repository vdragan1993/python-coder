# print the difference of 6 and 12
print(6 - 12)