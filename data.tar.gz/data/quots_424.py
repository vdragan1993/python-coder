# print the quotient of 15 and 5
print(15 / 5)