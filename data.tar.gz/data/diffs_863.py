# print the difference of 28 and 23
print(28 - 23)