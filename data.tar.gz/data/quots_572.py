# print the quotient of 20 and 3
print(20 / 3)