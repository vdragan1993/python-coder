# print sum of 3 and 14
print(3 + 14)