# print the difference of 19 and 5
print(19 - 5)