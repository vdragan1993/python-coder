# print the quotient of 25 and 1
print(25 / 1)