# print the sum of -1 and 1, if they are the same, then print double their sum
if -1 == 1:
    print(2 * (-1 + 1))
else:
    print(-1 + 1)