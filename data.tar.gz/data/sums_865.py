# print sum of 28 and 25
print(28 + 25)