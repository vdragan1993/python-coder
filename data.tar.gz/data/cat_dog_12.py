# print True if the string 'cat' and 'dog' appear the same number of times in the 
s = ''
print(s.count('cat') == s.count('dog'))
