# print the product of 5 and 11
print(5 * 11)