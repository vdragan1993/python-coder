# print sum of 25 and 12
print(25 + 12)