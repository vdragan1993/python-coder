# print the absolute difference between 1 and 21, except return double the absolute difference if 1 is over 21
if 1 > 21:
    print(2 * abs(1-21))
else:
    print(abs(1 - 21))