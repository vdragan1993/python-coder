# print the product of 26 and 28
print(26 * 28)