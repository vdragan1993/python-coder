# print the product of 23 and 28
print(23 * 28)