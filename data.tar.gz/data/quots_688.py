# print the quotient of 23 and 29
print(23 / 29)