# print the quotient of 4 and 26
print(4 / 26)