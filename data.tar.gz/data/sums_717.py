# print sum of 23 and 27
print(23 + 27)