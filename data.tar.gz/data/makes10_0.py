# print True if 9 or 10 is 10 or if their sum is 10
print(9 == 10 or 10 == 10 or 9+10 == 10)