# print array of second elements of arrays a=[1, 2, 3] and b=[4, 5, 6]
a = [1, 2, 3]
b = [4, 5, 6]
ret = []
ret.append(a[1])
ret.append(b[1])
print(ret)
