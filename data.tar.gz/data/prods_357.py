# print the product of 12 and 28
print(12 * 28)