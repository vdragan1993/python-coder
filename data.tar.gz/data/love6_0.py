# print True if either of a = 6 and b = 4 is 6, or if their sum or difference is 6
a = 6
b = 4
if a == 6 or b == 6 or a + b == 6 or abs(a-b) == 6:
    print('True')
else:
    print('False')
