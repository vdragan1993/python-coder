# print the quotient of 14 and 19
print(14 / 19)