# print the product of 19 and 16
print(19 * 16)