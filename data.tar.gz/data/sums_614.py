# print sum of 20 and 14
print(20 + 14)