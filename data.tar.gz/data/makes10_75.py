# print True if 12 or 1 is 10 or if their sum is 10
print(12 == 10 or 1 == 10 or 12+1 == 10)