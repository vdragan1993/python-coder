# print the difference of 10 and 16
print(10 - 16)