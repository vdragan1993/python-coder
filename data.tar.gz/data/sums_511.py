# print sum of 17 and 1
print(17 + 1)