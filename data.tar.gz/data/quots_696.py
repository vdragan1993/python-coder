# print the quotient of 24 and 7
print(24 / 7)