# print the quotient of 28 and 14
print(28 / 14)