# print sum of 29 and 24
print(29 + 24)