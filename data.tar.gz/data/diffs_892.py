# print the difference of 29 and 22
print(29 - 22)