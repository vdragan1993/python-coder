# print the number of 5's in the given array [1, 2, 3, 4, 5]
print([1, 2, 3, 4, 5].count(5))
