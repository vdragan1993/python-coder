# print the difference of 5 and 1, if they are the same, then print their sum
a = 5
b = 1
if a == b:
    print(a + b)
else:
    print(a - b)
