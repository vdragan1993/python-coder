# print the difference of 4 and 2, if they are the same, then print their sum
a = 4
b = 2
if a == b:
    print(a + b)
else:
    print(a - b)
