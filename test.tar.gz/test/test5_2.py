# print True if array [2, 3, 0, 4, 5] contains 0 and 5
nums = [2, 3, 0, 4, 5]
if 0 in nums and 5 in nums:
    print('True')
else:
    print('False')
