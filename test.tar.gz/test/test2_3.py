# print True if 2 is odd
print(2 % 2 == 1)
