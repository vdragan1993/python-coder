# print the number of 5's in the given array [5, 5, 5]
print([5, 5, 5].count(5))
