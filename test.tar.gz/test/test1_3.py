# print the difference of 2 and 2, if they are the same, then print their sum
a = 2
b = 2
if a == b:
    print(a + b)
else:
    print(a - b)
