# print a new string made of 2 copies of the first 2 chars of ABC
print('ABC'[:2] * 2)
