# print the number of 5's in the given array [1, 2, 3]
print([1, 2, 3].count(5))
