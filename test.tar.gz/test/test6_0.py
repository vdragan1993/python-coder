# print the number of times that string 'py' appears anywhere in the PYPYPYP
print('PYPYPYP'.count('py'))
