# print True if 4 is odd
print(4 % 2 == 1)
