# print True if 3 is odd
print(3 % 2 == 1)
