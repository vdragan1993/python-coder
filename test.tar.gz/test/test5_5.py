# print True if array [0, 0, 0] contains 0 and 5
nums = [0, 0, 0]
if 0 in nums and 5 in nums:
    print('True')
else:
    print('False')
