# print True if 1 is odd
print(1 % 2 == 1)
