# print the number of times that string 'py' appears anywhere in the java
print('java'.count('py'))
