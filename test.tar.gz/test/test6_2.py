# print the number of times that string 'py' appears anywhere in the python
print('python'.count('py'))
