# print the number of 5's in the given array [1]
print([1].count(5))
