# print the difference of 1 and 1, if they are the same, then print their sum
a = 1
b = 1
if a == b:
    print(a + b)
else:
    print(a - b)
