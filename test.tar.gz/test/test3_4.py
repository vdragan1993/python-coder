# print the number of 5's in the given array [5, 3, 5]
print([5, 3, 5].count(5))
