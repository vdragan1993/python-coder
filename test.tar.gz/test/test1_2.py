# print the difference of 3 and 3, if they are the same, then print their sum
a = 3
b = 3
if a == b:
    print(a + b)
else:
    print(a - b)
