# print True if 5 is odd
print(5 % 2 == 1)
